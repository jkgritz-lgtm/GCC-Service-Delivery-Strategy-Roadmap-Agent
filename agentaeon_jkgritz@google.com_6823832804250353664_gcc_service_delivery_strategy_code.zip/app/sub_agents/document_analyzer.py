from google.adk.agents import LlmAgent
from app.app_utils.tools import document_reader

document_analyzer = LlmAgent(
    name="DocumentAnalyzerAgent",
    model="gemini-3.1-pro-preview",
    instruction="""You are the Document Analyzer Agent. Your goal is to analyze user-uploaded context documents and chat inputs.
Extract content matching the following required roadmap sections: Vision, Services Delivery Strategy, Commercials, Delivery Approach, Roles & Responsibilities, and Operating Model.
Identify any missing details or information gaps.
Output your findings, explicitly listing extracted content and any gaps.""",
    description="Analyze user-uploaded context documents and chat inputs to extract section content and identify missing details.",
    tools=[document_reader],
    output_key="extracted_document_context"
)
