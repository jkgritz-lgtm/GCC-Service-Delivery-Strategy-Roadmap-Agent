# Project name used for resource naming
project_name = "gcc-delivery-strategy"

# Your Google Cloud project id
project_id = "agent-catalog-demo-1"

# The Google Cloud region you will use to deploy the infrastructure
region = "us-central1"
