import os
import google.auth
from google.adk.apps import App
from google.adk.agents import SequentialAgent, LlmAgent
from app.sub_agents.document_analyzer import document_analyzer
from app.sub_agents.strategy_synthesizer import strategy_synthesizer
from app.sub_agents.slides_generator import slides_generator

try:
    _, project_id = google.auth.default()
except Exception:
    project_id = "agent-catalog-demo-1" # Fallback if local auth is missing

os.environ["GOOGLE_CLOUD_PROJECT"] = project_id
os.environ["GOOGLE_CLOUD_LOCATION"] = "global"
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"

# Main Sequential Orchestrator
pipeline_agent = SequentialAgent(
    name="GCC_Service_Delivery_Strategy_Pipeline",
    description="A sequential pipeline to analyze documents, synthesize strategy with clarifications, and generate a Google Slides presentation.",
    sub_agents=[
        document_analyzer,
        strategy_synthesizer,
        slides_generator
    ]
)

# Root agent that interacts with the user and delegates to the pipeline.
root_agent = LlmAgent(
    name="GCC_Service_Delivery_Strategy_Agent",
    model="gemini-3.1-pro-preview",
    instruction="""You are the main orchestrator for the GCC Service Delivery Strategy.
Your job is to assist the user by taking their inputs (documents and chat) and passing them into the `GCC_Service_Delivery_Strategy_Pipeline`.
Delegate the task to `GCC_Service_Delivery_Strategy_Pipeline` to perform document analysis, strategy synthesis, and Google Slides generation.
Once the pipeline is complete, summarize the results and provide the presentation link.""",
    description="Main orchestrator agent controlling the GCC Service Delivery Strategy pipeline. Manages multi-agent execution across analysis, clarification/assumptions, synthesis, and Google Slides output creation.",
    sub_agents=[pipeline_agent]
)

app = App(
    root_agent=root_agent,
    name="app",
)
