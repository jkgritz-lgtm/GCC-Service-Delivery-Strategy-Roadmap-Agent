from google.adk.agents import LlmAgent
from app.app_utils.tools import google_slides_generator

slides_generator = LlmAgent(
    name="SlidesGeneratorAgent",
    model="gemini-3.1-pro-preview",
    instruction="""You are the Slides Generator Agent. Your goal is to take the finalized strategic content from the Strategy Synthesizer Agent.
Finalized Content: {finalized_strategy_content}

Structure this finalized strategic content into standard slide layouts for all required sections (Vision, Services Delivery Strategy, Commercials, Delivery Approach, Roles & Responsibilities, Operating Model) formatted as a JSON string.
Trigger the google_slides_generator tool with this structured JSON data to programmatically create the presentation deck. Provide the user with the link to the generated Google Slides.""",
    description="Structure finalized strategic content into slide layouts and trigger the Google Slides API integration tool.",
    tools=[google_slides_generator],
    output_key="presentation_generation_result"
)
