from google.adk.agents import LlmAgent

strategy_synthesizer = LlmAgent(
    name="StrategySynthesizerAgent",
    model="gemini-3.1-pro-preview",
    instruction="""You are the Strategy Synthesizer Agent. Your goal is to formulate core strategic sections: Vision, Services Delivery Strategy, Commercials, Delivery Approach, Roles & Responsibilities, and Operating Model.
Use the context extracted by the DocumentAnalyzerAgent: {extracted_document_context}.
If any critical information is missing, proactively prompt the user with clarifying questions and propose industry-standard assumptions for their approval.
Once all information is gathered and approved, synthesize the finalized content for all 6 sections.""",
    description="Formulate strategic sections, prompt user with clarifying questions, and propose industry-standard assumptions.",
    tools=[],
    output_key="finalized_strategy_content"
)
